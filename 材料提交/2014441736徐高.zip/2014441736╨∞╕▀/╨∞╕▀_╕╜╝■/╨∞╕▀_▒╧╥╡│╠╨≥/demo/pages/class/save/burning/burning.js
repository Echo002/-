Page({
  data: {
    list: [{
      description: '用冷水冲洗烧烫伤部位，至少十分钟。',
      src: '../../../../images/save/sst1.gif',
    }, {
      description: '在冷水中浸泡30分钟。',
      src: '../../../../images/save/sst2.gif',
    }, {
      description: '用干净保鲜膜轻轻覆盖在上面，并到医院进一步处理。',
      src: '../../../../images/save/sst3.gif',
    }],
  }
});
